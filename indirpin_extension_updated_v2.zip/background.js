
chrome.action.onClicked.addListener((tab) => {
    if (tab.url.match(/https:\/\/.*\.pinterest\.com\/pin\/\d+/)) {
        chrome.action.setBadgeText({ text: "1" });
    } else {
        chrome.action.setBadgeText({ text: "" });
    }
});
