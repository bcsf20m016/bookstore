
chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const url = tabs[0].url;
    const pinStatus = document.getElementById("pin-status");
    const downloadButton = document.getElementById("download-btn");

    // Check if the URL is a Pinterest pin page
    if (url.match(/https:\/\/.*\.pinterest\.com\/pin\/\d+/)) {
        pinStatus.innerHTML = "<p id='pin-found'>Pin Found!</p>";
        downloadButton.style.display = "inline-block"; // Show the download button
        downloadButton.addEventListener("click", function () {
            const indirPinUrl = `https://yourwebsite.com?url=${encodeURIComponent(url)}`;
            window.open(indirPinUrl, "_blank");
        });
        chrome.action.setBadgeText({ text: "1" }); // Set badge when on a pin page
        chrome.action.setBadgeBackgroundColor({ color: "#5cb85c" }); // Set badge color to green
    } else {
        pinStatus.innerHTML = "<p id='no-pin'>No Pin Found</p>";
        chrome.action.setBadgeText({ text: "" }); // Clear badge if not on a pin page
    }
});
