
document.addEventListener('DOMContentLoaded', function () {
    // Ensuring both message and button are visible once the popup is loaded
    const message = document.getElementById('message');
    const downloadButton = document.getElementById('downloadButton');
    
    if (message) {
        message.style.display = 'block';
    }
    
    if (downloadButton) {
        downloadButton.style.display = 'block';
        downloadButton.addEventListener('click', function () {
            // Placeholder for actual download functionality
            alert('Download initiated!');
        });
    }
});
