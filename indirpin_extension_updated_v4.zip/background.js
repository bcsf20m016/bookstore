
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url.includes('pinterest.com/pin/')) {
        chrome.action.setBadgeText({ tabId: tabId, text: '1' });
        chrome.action.setBadgeBackgroundColor({ color: '#00FF00' });
    }
});


chrome.action.onClicked.addListener((tab) => {
    if (tab.url.match(/https:\/\/.*\.pinterest\.com\/pin\/\d+/)) {
        chrome.action.setBadgeText({ text: "1" });
    } else {
        chrome.action.setBadgeText({ text: "" });
    }
});
